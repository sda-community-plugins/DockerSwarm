package com.serena.air

class Validation {
    public static void fileMustExist(String file) throws StepFailedException{
        fileMustExist(new File(file))
    }
    public static void fileMustExist(File file) throws StepFailedException{
        fileMustExist(file, 'File does not exist')
    }

    public static void fileMustExist(File file, String errorMessage) throws StepFailedException{
        if(!file.exists() ){
            throw new StepFailedException("$errorMessage: ${file.absolutePath}")
        }
    }

    public static void mustBeNotNull(Object obj, String errorMessage) throws StepFailedException{
        if(obj == null){
            throw new StepFailedException(errorMessage)
        }
    }

    public static void atLeastOneValid(List list, String errMsg){
        atLeastOneValid(list, errMsg, null)
    }
    public static void atLeastOneValid(List list, String errMsg, Closure clos){
        Closure check = clos
        if(check == null){
            check = {
                if (it instanceof String){
                    return ( it != null && !it.isEmpty() )
                }
                return it != null
            }
        }
        if (!list.any (check)){
            throw new StepFailedException(errMsg)
        }
    }
}
