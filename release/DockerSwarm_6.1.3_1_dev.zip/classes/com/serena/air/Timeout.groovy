package com.serena.air

class Timeout {
    private long start
    private int  timeoutMilis

    public void setTimeoutSeconds(int timeout){
        setTimeoutMilis(timeout * 1000)
    }

    public void setTimeoutMilis(int timeout){
        timeoutMilis = timeout
        start = System.currentTimeMillis()
    }

    public void check() throws StepFailedException{
        if(timeoutMilis < 0){
            return
        }

        long current = System.currentTimeMillis()
        if(current - start > timeoutMilis){
            throw new StepFailedException('Failed by timeout!')
        }
    }
}
